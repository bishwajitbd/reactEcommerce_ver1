export const UserActionType={
	SET_CURRENT_USER: 'SET_CURRENT_USER'
}